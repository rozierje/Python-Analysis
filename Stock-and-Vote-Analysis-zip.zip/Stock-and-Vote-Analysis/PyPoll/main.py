# import operating system
import os

# impoert the csv reader
import csv
#locate csv file for election results
csvpath = os.path.join('..', 'PyPoll', 'Resources', 'election_data.csv')
#create empty carts for candidate list
candidate_list = []
#set vote count total
votes = 0

# Format Final Table
print("Election Results")
print("-------------------")

#Gather Total Votes
with open(csvpath) as election_results:

    # CSV reader specifies delimiter and variable that holds contents
    csvreader = csv.reader(election_results, delimiter=',')
 
    # Read each row of data after the header
    for vote in csvreader:
       votes += 1
    print("Total Votes")
    print(votes)
    print("-----------------------")
#-------------------- good to this point------------------------------        
    
   # for vote in csvreader:
    #    while vote[2] 
   # print(candidate_list)



################### write new test file ########################

# Specify the file to write to
output_path = os.path.join("..", "PyPoll", "Resources", "results.csv")

# Open the file using "write" mode. Specify the variable to hold the contents
with open(output_path, 'w', newline='') as csvfile:

    # Initialize csv.writer
    csvwriter = csv.writer(csvfile, delimiter=',')

    # Write the first row (column headers)
    csvwriter.writerow("Election Results")
    csvwriter.writerow("-------------------------------------")
    # Write the second row
    csvwriter.writerow("Total Votes: " + votes +" ")
    csvwriter.writerow("--------------------------------------")
    csvwriter.writerow(["Candidate", "Votes", "Percentage"])

    csvwriter.writerow("--------------------------------------")
    csvwriter.writerow("--------------------------------------")
    csvwriter.writerow("--------------------------------------")