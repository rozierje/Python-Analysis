# Python-Analysis
* This code runs a series of totals based on raw financial and voting data.
